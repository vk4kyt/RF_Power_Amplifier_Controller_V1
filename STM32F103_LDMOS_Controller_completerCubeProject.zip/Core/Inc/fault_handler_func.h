/*
 * fault_handler_func.h
 *
 *  Created on: Sep 4, 2023
 *      Author: sp6gk
 */

#ifndef INC_FAULT_HANDLER_FUNC_H_
#define INC_FAULT_HANDLER_FUNC_H_

void fault_handler(uint8_t fault_nr);


#endif /* INC_FAULT_HANDLER_FUNC_H_ */
